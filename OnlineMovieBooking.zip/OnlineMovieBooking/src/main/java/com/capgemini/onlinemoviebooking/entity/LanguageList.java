package com.capgemini.onlinemoviebooking.entity;

public enum LanguageList {
	
	
	
	Hindi,
//	("Hindi"),
	English,
//	("English"),
	Kannada,
//	("Kannada"),
	Telugu,   
//	("Telugu"),
	Tamil,
//	("Tamil"),
	Malayalam
//	("Malayalam");

//    private final String language;
//	LanguageList(final String language) {
//		
//		this.language=language;
//	}
//	@Override
//	public String toString() {
//		return language;
//	}

}
